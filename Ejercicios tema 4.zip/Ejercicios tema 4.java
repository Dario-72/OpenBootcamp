int numeroIf ;

if (numeroIf > 0){

}else if (numeroIf < 0){

}else{

}
--------------------------

int numeroWhile ;
while (numeroWhile < 3){
  System.out.println(nomeroWhile);
  numeroWhile = numeroWhile ++;
}

-----------------------------

int numeroWhile = 2;
do{
  System.out.println(nomeroWhile);
}
while (numeroWhile < 3){
  numeroWhile = numeroWhile ++;
}

------------------------------

int numeroFor = 0;

for(int i = numeroFor; i = 3; i++){
  System.out.println(i);
}

-----------------------------

int estacion;
switch (estacion) {
  case otoño:
    System.out.println("Estamos en otoño");
    break;
  case invierno:
    System.out.println("Estamos en invierno");
    break;
  case primavera:
    System.out.println("Estamos en primavera");
    break;
    case verano:
    System.out.println("Estamos en verano");
    break;
  default:
    System.out.println("El valor de la variable no es una estacion");
    break;
}